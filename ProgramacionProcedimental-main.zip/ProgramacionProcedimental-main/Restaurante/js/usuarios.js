let nombre = document.getElementById("nombre");
let apellido = document.getElementById("apellido");
let telefono = document.getElementById("telefono");
let numero_documento = document.getElementById("numero_documento");
let correo = document.getElementById("correo");
let cargo = document.getElementById("cargo");
let fecha_nacimiento = document.getElementById("fecha_nacimiento");
let contrasena = document.getElementById("contrasena");
