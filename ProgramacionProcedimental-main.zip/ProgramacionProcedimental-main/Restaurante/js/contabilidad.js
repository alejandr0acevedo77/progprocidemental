let Ingresos = document.getElementById("Ingresos");
let Egresos = document.getElementById("Egresos");
let Concepto = document.getElementById("Concepto");
let Fecha = document.getElementById("Fecha");







const label = document.getElementById("Ingresos");
const label = document.getElementById("Egresos");
const label = document.getElementById("Concepto");
const label = document.getElementById("Fecha");
