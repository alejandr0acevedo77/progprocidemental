let Producto = document.getElementById("Producto");
let Dirección = document.getElementById("Dirección");
let Nombre = document.getElementById("Nombre");
let descripcion = document.getElementById("descripcion");
let Pago = document.getElementById("Pago");
let valor = document.getElementById("valor");
let Telefono = document.getElementById("Telefono");

