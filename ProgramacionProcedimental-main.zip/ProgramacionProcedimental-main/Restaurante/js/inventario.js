let Codigo = document.getElementById("codigo");
let Nombre = document.getElementById("nombre");
let Cantidad = document.getElementById("cantidad");
let descripcion = document.getElementById("descripcion");
let marca = document.getElementById("marca");
let valor = document.getElementById("valor");
let categoria = document.getElementById("categoria");
let ubicacion = document.getElementById("ubicacion");

